Título: Calculadora Hidrológica CAUMAX y Herramientas GIS.

Descripción: Un resumen de lo que hace la aplicación.

Instalación:

Clonar el repositorio.

Crear un entorno virtual (python -m venv venv).

Instalar las dependencias (pip install -r requirements.txt).

Configuración de Datos: Explicar cómo obtener los archivos de la carpeta data/ (ej. "Descargar desde este enlace y colocar en la carpeta data/").

Configuración del Script Externo (Muy Importante):

Explicar que se necesita un segundo entorno virtual para el script de pysheds.

Dar instrucciones para crearlo (ej. python -m venv Py2Env/venv_pysheds) y cómo instalar las librerías necesarias en él.

Cómo Ejecutar: El comando streamlit run app.py