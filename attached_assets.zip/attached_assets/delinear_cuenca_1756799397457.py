# -*- coding: utf-8 -*-

# 1. Imports
# -*- coding: utf-8 -*-

import sys
import os
import json

# --- INICIO DE LA MODIFICACIÓN ---
# Forzar la salida estándar a UTF-8. Añadir esto justo después de los imports.
if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')
if sys.stderr.encoding != 'utf-8':
    sys.stderr.reconfigure(encoding='utf-8')
# --- FIN DE LA MODIFICACIÓN ---

import matplotlib.pyplot as plt
import numpy as np
from pysheds.grid import Grid
import matplotlib.colors as colors

# Importaciones para exportar
import geopandas as gpd
from shapely.geometry import Point, Polygon, LineString
from rasterio import features
import rasterio

# ==================================================================
# PASO 2: LECTURA DE DATOS DE ENTRADA
# ==================================================================
dem_file = "elevation.tif"
outlet_file = "outlet_coord.txt"

with open(outlet_file, 'r') as f:
    x_str, y_str = f.read().split()
    x, y = float(x_str), float(y_str)
print(f"Punto de vertido leído: X={x}, Y={y}")

# Carga el DEM
no_data_value = -32768
grid = Grid.from_raster(dem_file, nodata=no_data_value)
dem = grid.read_raster(dem_file, nodata=no_data_value)

# ==================================================================
# PASO 3: PROCESAMIENTO HIDROLÓGICO COMPLETO
# (Hacemos todos los cálculos aquí, antes de cualquier gráfico)
# ==================================================================
print("Procesando DEM y delineando cuenca...")

# Acondicionamiento
pit_filled_dem = grid.fill_pits(dem)
flooded_dem = grid.fill_depressions(pit_filled_dem)
conditioned_dem = grid.resolve_flats(flooded_dem)

# Dirección y acumulación de flujo
flowdir = grid.flowdir(conditioned_dem)
acc = grid.accumulation(flowdir)

# Delineación de la cuenca
umbral_acumulacion = 5000
x_snap, y_snap = grid.snap_to_mask(acc > umbral_acumulacion, (x, y))
catch = grid.catchment(x=x_snap, y=y_snap, fdir=flowdir, xytype="coordinate")

print("Procesamiento hidrológico completado.")

# ==================================================================
# AHORA QUE TENEMOS TODO CALCULADO, EMPEZAMOS CON LOS GRÁFICOS
# ==================================================================

# GRÁFICO 1: MOSAICO DE CARACTERÍSTICAS DE LA CUENCA (ESTILO WEB)
print("Generando Gráfico 1: Mosaico de características de la cuenca...")
grid_para_plot = Grid.from_raster(dem_file, nodata=no_data_value)
grid_para_plot.clip_to(catch)
catch_view = grid_para_plot.view(catch, nodata=np.nan)
dem_view = grid_para_plot.view(conditioned_dem, nodata=np.nan)
fdir_view = grid_para_plot.view(flowdir, nodata=np.nan)
acc_view = grid_para_plot.view(acc, nodata=np.nan)
plot_extent = grid_para_plot.extent

fig, axes = plt.subplots(2, 2, figsize=(12, 10))
axes[0, 0].imshow(catch_view, extent=plot_extent, cmap='Greys_r')
axes[0, 0].set_title("Extensión de la Cuenca")
axes[0, 0].set_ylabel("Coordenada Y (UTM)")
im_dem = axes[0, 1].imshow(dem_view, extent=plot_extent, cmap='viridis')
axes[0, 1].set_title("Elevación")
fig.colorbar(im_dem, ax=axes[0, 1], label='Elevación (m)', shrink=0.7)
im_fdir = axes[1, 0].imshow(fdir_view, extent=plot_extent, cmap='twilight')
axes[1, 0].set_title("Dirección de Flujo")
axes[1, 0].set_xlabel("Coordenada X (UTM)")
axes[1, 0].set_ylabel("Coordenada Y (UTM)")
im_acc = axes[1, 1].imshow(acc_view, extent=plot_extent, cmap='cubehelix', norm=colors.LogNorm(vmin=1, vmax=acc.max()))
axes[1, 1].set_title("Acumulación de Flujo")
axes[1, 1].set_xlabel("Coordenada X (UTM)")
fig.colorbar(im_acc, ax=axes[1, 1], label='Número de celdas aguas arriba', shrink=0.7)
plt.suptitle("Características de la Cuenca Delineada", fontsize=16)
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()

# GRÁFICO 2: VISUALIZACIÓN COMPLETA DE LA CUENCA Y RED FLUVIAL
print("Mostrando Gráfico 2: Cuenca, Red Fluvial y Punto de Vertido...")
umbral_rio_visual = 100
river_network_visual = acc > umbral_rio_visual
fig, ax = plt.subplots(figsize=(10, 8))
plt.imshow(np.where(catch, 1, np.nan), extent=grid.extent, cmap='Greens', alpha=0.8, zorder=1)
plt.imshow(np.where(river_network_visual & catch, 1, np.nan), extent=grid.extent, cmap='Blues', zorder=2)
plt.plot(x_snap, y_snap, 'ro', markersize=8, label='Punto de vertido', zorder=3)
plt.title("Cuenca hidrográfica delineada con Red Fluvial")
plt.xlabel("Coordenada X (UTM)")
plt.ylabel("Coordenada Y (UTM)")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# GRÁFICO 3: LFP SOBRE EL DEM DE LA CUENCA
print("Calculando y mostrando Gráfico 3: LFP sobre el DEM de la cuenca...")
dist = grid._d8_flow_distance(x=x_snap, y=y_snap, fdir=flowdir, xytype='coordinate')
dist_catch = np.where(catch, dist, -1)
start_row, start_col = np.unravel_index(np.argmax(dist_catch), dist_catch.shape)
dirmap = {1:(0,1), 2:(1,1), 4:(1,0), 8:(1,-1), 16:(0,-1), 32:(-1,-1), 64:(-1,0), 128:(-1,1)}
lfp_coords = []
current_row, current_col = start_row, start_col
with rasterio.open(dem_file) as src: raster_transform = src.transform
while catch[current_row, current_col]:
    x_coord, y_coord = raster_transform * (current_col, current_row); x_coord += raster_transform.a / 2.0; y_coord += raster_transform.e / 2.0
    lfp_coords.append((x_coord, y_coord))
    direction = flowdir[current_row, current_col];
    if direction == 0: break
    row_move, col_move = dirmap[direction]; current_row += row_move; current_col += col_move
grid.clip_to(catch)
dem_cuenca_recortada = grid.view(conditioned_dem, nodata=np.nan)
fig, ax = plt.subplots(figsize=(10, 8))
plt.imshow(dem_cuenca_recortada, extent=grid.extent, cmap='terrain', zorder=1)
plt.colorbar(label='Elevación (m)')
x_coords, y_coords = zip(*lfp_coords)
plt.plot(x_coords, y_coords, color='red', linewidth=2, label='Longest Flow Path', zorder=2)
plt.title('Camino de Flujo Más Largo (LFP) de la cuenca')
plt.xlabel('Coordenada X (UTM)'); plt.ylabel('Coordenada Y (UTM)'); plt.legend(); plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# GRÁFICO 4: PERFIL LONGITUDINAL DEL LFP
print("Generando Gráfico 4: Perfil Longitudinal del LFP...")
with rasterio.open(dem_file) as src: fwd_transform = src.transform; inv_transform = ~fwd_transform
profile_elevations = []; valid_lfp_coords = []
for x_coord, y_coord in lfp_coords:
    try:
        col, row = inv_transform * (x_coord, y_coord); row_idx, col_idx = int(row), int(col)
        elevation = conditioned_dem[row_idx, col_idx]; profile_elevations.append(elevation); valid_lfp_coords.append((x_coord, y_coord))
    except IndexError: continue
profile_distances = [0]
for i in range(1, len(valid_lfp_coords)):
    x1, y1 = valid_lfp_coords[i-1]; x2, y2 = valid_lfp_coords[i]
    segment_dist = np.sqrt((x2 - x1)**2 + (y2 - y1)**2); profile_distances.append(profile_distances[-1] + segment_dist)
profile_distances_km = np.array(profile_distances) / 1000
fig, ax = plt.subplots(figsize=(12, 6))
ax.plot(profile_distances_km, profile_elevations, color='darkblue', label='Perfil del Terreno')
ax.fill_between(profile_distances_km, profile_elevations, alpha=0.2, color='lightblue')
ax.set_title('Perfil Longitudinal del Camino de Flujo Más Largo (LFP)')
ax.set_xlabel('Distancia desde el origen (kilómetros)'); ax.set_ylabel('Elevación (metros)'); ax.grid(True, linestyle='--', alpha=0.7); ax.legend()
plt.show()

# GRÁFICO 5: HISTOGRAMA DE ELEVACIONES
print("Generando Gráfico 5: Histograma de Elevaciones...")
dem_cuenca = np.where(catch, conditioned_dem, np.nan)
elevaciones_cuenca = dem_cuenca[~np.isnan(dem_cuenca)]
fig, ax = plt.subplots(figsize=(10, 6))
ax.hist(elevaciones_cuenca, bins=50, color='skyblue', edgecolor='black')
ax.set_title('Distribución de Elevaciones en la Cuenca'); ax.set_xlabel('Elevación (metros)'); ax.set_ylabel('Frecuencia (número de píxeles)'); ax.grid(True, linestyle='--', alpha=0.7)
plt.show()

# # GRÁFICO 6: CURVA HIPSOMÉTRICA
# print("Generando Gráfico 6: Curva Hipsométrica...")
# elev_sorted = np.sort(elevaciones_cuenca)[::-1]
# with rasterio.open(dem_file) as src: transform = src.transform; cell_area = abs(transform.a * transform.e)
# pixel_count = np.arange(1, len(elev_sorted) + 1); area_acumulada = pixel_count * cell_area
# area_normalizada = area_acumulada / area_acumulada.max()
# elev_normalizada = (elev_sorted - elev_sorted.min()) / (elev_sorted.max() - elev_sorted.min())
# integral_hipsometrica = abs(np.trapz(area_normalizada, x=elev_normalizada))
# fig, ax = plt.subplots(figsize=(10, 8))
# ax.plot(area_normalizada, elev_sorted, color='red', linewidth=2, label='Basin hypsometric curve')
# elev_max = elev_sorted.max(); elev_min = elev_sorted.min()
# ax.plot([0, 1], [elev_max, elev_min], color='gray', linestyle='--', linewidth=2, label='Linear reference (HI = 0.5)')
# ax.text(0.05, 0.1, f'Hypsometric integral: {integral_hipsometrica:.3f}', transform=ax.transAxes, fontsize=14, bbox=dict(facecolor='white', alpha=0.8, edgecolor='none'))
# ax.set_title('Curva Hipsométrica de la Cuenca', fontsize=16); ax.set_xlabel('Area fraction above elevation (a/A)', fontsize=14); ax.set_ylabel('Elevation (m)', fontsize=14)
# ax.grid(True, linestyle=':', color='gray', alpha=0.7); ax.legend(fontsize=12); ax.set_xlim(0, 1); ax.set_ylim(bottom=elev_min - 100)
# plt.show()

# ==================================================================
# GRÁFICO 6: CURVA HIPSOMÉTRICA (VERSIÓN FINAL, ESTILO WEB)
# ==================================================================
print("Generando Gráfico 6: Curva Hipsométrica...")

# --- CÁLCULOS (YA SON CORRECTOS) ---
# Ordenar las elevaciones de la cuenca de mayor a menor
elev_sorted = np.sort(elevaciones_cuenca)[::-1]
# Calcular el área de un píxel
with rasterio.open(dem_file) as src:
    transform = src.transform
    cell_area = abs(transform.a * transform.e)
# Calcular el área acumulada
pixel_count = np.arange(1, len(elev_sorted) + 1)
area_acumulada = pixel_count * cell_area
# Normalizar el área (a/A)
area_normalizada = area_acumulada / area_acumulada.max()
# Normalizar la elevación (h/H) para el cálculo de la integral
elev_normalizada = (elev_sorted - elev_sorted.min()) / (elev_sorted.max() - elev_sorted.min())
# Calcular la Integral Hipsométrica (y corregir el signo)
integral_hipsometrica = abs(np.trapz(area_normalizada, x=elev_normalizada))

# --- GRÁFICO (CON EL SOMBREADO AÑADIDO) ---
fig, ax = plt.subplots(figsize=(10, 8))

# 1. Dibujar la curva hipsométrica (Elevación real vs. Área normalizada)
ax.plot(area_normalizada, elev_sorted, color='red', linewidth=2, label='Basin hypsometric curve')

# ***** LA LÍNEA NUEVA ESTÁ AQUÍ *****
# Añadimos el sombreado por debajo de la curva roja.
# Le decimos que rellene el área entre la curva (elev_sorted) y la elevación mínima.
elev_min = elev_sorted.min()
ax.fill_between(area_normalizada, elev_sorted, elev_min, color='red', alpha=0.2)

# 2. Dibujar la línea de referencia lineal (sin sombreado)
elev_max = elev_sorted.max()
ax.plot([0, 1], [elev_max, elev_min], color='gray', linestyle='--', linewidth=2, label='Linear reference (HI = 0.5)')

# 3. Añadir el texto con el valor de la integral
ax.text(0.05, 0.1, f'Hypsometric integral: {integral_hipsometrica:.3f}', 
        transform=ax.transAxes, fontsize=14, 
        bbox=dict(facecolor='white', alpha=0.8, edgecolor='none'))

# 4. Configurar etiquetas, título y estilo
ax.set_title('Curva Hipsométrica de la Cuenca', fontsize=16)
ax.set_xlabel('Area fraction above elevation (a/A)', fontsize=14)
ax.set_ylabel('Elevation (m)', fontsize=14)
ax.grid(True, linestyle=':', color='gray', alpha=0.7)
ax.legend(fontsize=12)
ax.set_xlim(0, 1)
ax.set_ylim(bottom=elev_min - 100)
plt.show()




# ==================================================================
# EXPORTACIÓN A SHAPEFILE (MÉTODO FINAL Y ROBUSTO)
# ==================================================================
print("\n--- INICIANDO EXPORTACIÓN A SHAPEFILE ---")

# Restauramos el 'grid' a su estado original para asegurar la georreferenciación correcta
grid = Grid.from_raster(dem_file, nodata=no_data_value)

output_dir = 'results'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
output_crs = "EPSG:25830"

try:
    with rasterio.open(dem_file) as src:
        raster_transform = src.transform

    # --- Preparación y guardado de archivos en el orden solicitado ---

    # Paso 1/4: Exportando el PUNTO DE SALIDA
    print("Paso 1/4: Exportando el punto de salida...")
    punto_geom = Point(x_snap, y_snap)
    gdf_punto = gpd.GeoDataFrame({'id': [1], 'geometry': [punto_geom]}, crs=output_crs)
    punto_shp_path = os.path.join(output_dir, 'punto_salida.shp')
    gdf_punto.to_file(punto_shp_path)
    print(f"   -> Punto de salida guardado en: {punto_shp_path}")

    # Paso 2/4: Exportando el LONGEST FLOW PATH
    print("Paso 2/4: Exportando el Longest Flow Path...")
    lfp_geom = LineString(lfp_coords)
    gdf_lfp = gpd.GeoDataFrame({'id': [1], 'geometry': [lfp_geom]}, crs=output_crs)
    lfp_shp_path = os.path.join(output_dir, 'lfp.shp')
    gdf_lfp.to_file(lfp_shp_path)
    print(f"   -> LFP guardado en: {lfp_shp_path}")

    # Paso 3/4: Exportando la CUENCA
    print("Paso 3/4: Vectorizando la cuenca...")
    catch_data = grid.view(catch, dtype=np.uint8)
    shapes = features.shapes(catch_data, mask=catch_data, transform=raster_transform)
    cuenca_geom = [Polygon(s['coordinates'][0]) for s, v in shapes if v == 1][0]
    gdf_cuenca = gpd.GeoDataFrame({'id': [1], 'geometry': [cuenca_geom]}, crs=output_crs)
    cuenca_shp_path = os.path.join(output_dir, 'cuenca.shp')
    gdf_cuenca.to_file(cuenca_shp_path)
    print(f"   -> Cuenca guardada en: {cuenca_shp_path}")

    # Paso 4/4: Exportando los RÍOS (con el método rápido y predecible)
    print("Paso 4/4: Vectorizando y recortando la red fluvial...")
    
    umbral_rio_export = 5000 
    
    river_raster = acc > umbral_rio_export
    shapes = features.shapes(river_raster.astype(np.uint8), 
                             mask=river_raster, 
                             transform=raster_transform)
    
    river_geoms = [LineString(s['coordinates'][0]) for s, v in shapes if v == 1]
    gdf_rios_full = gpd.GeoDataFrame(geometry=river_geoms, crs=output_crs)

    gdf_rios_recortado = gpd.clip(gdf_rios_full, gdf_cuenca)

    # ***** LA SOLUCIÓN DEFINITIVA (Y YA CONOCIDA) ESTÁ AQUÍ *****
    # Al igual que antes, filtramos para quedarnos solo con las LÍNEAS
    # y eliminar cualquier PUNTO que se haya podido generar.
    gdf_rios_final = gdf_rios_recortado[gdf_rios_recortado.geom_type == 'LineString']
    
    rios_shp_path = os.path.join(output_dir, 'rios.shp')
    gdf_rios_final.to_file(rios_shp_path)
    print(f"   -> Red fluvial (umbral {umbral_rio_export}, recortada) guardada en: {rios_shp_path}")

    print("\n¡Exportación completada con éxito!")

except Exception as e:
    print("\n--- ERROR INESPERADO DURANTE LA EXPORTACIÓN ---")
    import traceback
    traceback.print_exc()


# ==================================================================
# ANÁLISIS ADICIONAL (MÉTODO pyflwdir + matplotlib DIRECTO)
# ==================================================================
import pyflwdir

print("\n--- INICIANDO ANÁLISIS ADICIONAL CON pyflwdir ---")

# --- Preparación: Crear un objeto FlwDir nativo desde el DEM original ---
print("Inicializando pyflwdir desde el array del DEM...")
with rasterio.open(dem_file) as src:
    dem_data = src.read(1)
    transform = src.transform
    crs = src.crs

flw = pyflwdir.from_dem(
    data=dem_data,
    nodata=no_data_value,
    transform=transform,
    latlon=False
)
upa = flw.upstream_area(unit='cell')

# # ==================================================================
# # ANÁLISIS ADICIONAL 1: SUBCUENCAS POR ORDEN DE RED FLUVIAL (STRAHLER)
# # ==================================================================
# from matplotlib.lines import Line2D # Importamos para la leyenda personalizada
# 
# print("\n--- INICIANDO ANÁLISIS ADICIONAL ---")
# 
# # Restauramos el 'grid' a su estado original
# grid = Grid.from_raster(dem_file, nodata=no_data_value)
# 
# # --- Preparación con pyflwdir ---
# import pyflwdir
# with rasterio.open(dem_file) as src:
#     dem_data = src.read(1)
#     transform = src.transform
#     crs = src.crs
# flw = pyflwdir.from_dem(data=dem_data, nodata=no_data_value, transform=transform, latlon=False)
# upa = flw.upstream_area(unit='cell')
# 
# 
# print("Generando Gráfico 7: Subcuencas por Orden de Red Fluvial (Strahler)...")
# 
# # --- CÁLCULOS (Volvemos al método que funcionaba) ---
# 
# # Paso 1: Delinear subcuencas para ríos con un orden de Strahler mínimo de 7.
# # Esto nos da el mapa de subcuencas con IDs arbitrarios, que es el que te gustaba.
# subbas_strahler, idxs_out_strahler = flw.subbasins_streamorder(min_sto=8)
# 
# # Paso 2: FILTRAR los puntos de salida (sin cambios)
# idxs_out_filtrados = [idx for idx in idxs_out_strahler if catch[np.unravel_index(idx, flw.shape)]]
# if idxs_out_filtrados:
#     x_outlets, y_outlets = flw.xy(idxs_out_filtrados)
# else:
#     x_outlets, y_outlets = [], []
# 
# # --- VISUALIZACIÓN (Mantenemos el mapa y cambiamos solo la leyenda) ---
# 
# # Enmascaramos el mapa de subcuencas para plotearlo, como antes
# subbas_strahler_masked = np.where(catch, subbas_strahler, np.nan)
# subbas_strahler_masked = np.where(subbas_strahler_masked > 0, subbas_strahler_masked, np.nan)
# 
# fig, ax = plt.subplots(figsize=(10, 8))
# 
# # Dibujar el mapa de subcuencas
# cmap = plt.get_cmap('tab20b')
# im = ax.imshow(subbas_strahler_masked, extent=grid.extent, cmap=cmap, zorder=1)
# # Dibujar los puntos de salida
# ax.scatter(x_outlets, y_outlets, color='black', s=30, zorder=2)
# 
# # --- CREACIÓN DE LA LEYENDA DISCRETA Y SIGNIFICATIVA ---
# 
# # 1. Calculamos el orden de Strahler para poder etiquetar las cuencas
# strahler_orders = flw.stream_order()
# # 2. Encontramos los IDs únicos de las subcuencas que estamos mostrando
# unique_basins = np.unique(subbas_strahler_masked[~np.isnan(subbas_strahler_masked)])
# # 3. Creamos las etiquetas para la leyenda
# legend_elements = []
# for basin_id in unique_basins:
#     # Para cada subcuenca, encontramos el orden de su río principal
#     mask = subbas_strahler_masked == basin_id
#     max_order_in_basin = int(np.max(strahler_orders[mask]))
#     # Obtenemos el color que matplotlib le ha asignado
#     color = im.cmap(im.norm(basin_id))
#     # Creamos el elemento de la leyenda
#     legend_elements.append(Line2D([0], [0], marker='o', color='w',
#                                   markerfacecolor=color, markersize=10,
#                                   label=f'Orden {max_order_in_basin}'))
# 
# ax.legend(handles=legend_elements, title="Orden del Río Principal", 
#           frameon=True, loc='upper right')
# 
# ax.set_title('Subcuencas por Orden de Red Fluvial Mínimo (Strahler)')
# ax.set_xlabel('Coordenada X (UTM)')
# ax.set_ylabel('Coordenada Y (UTM)')
# plt.grid(True, linestyle='--', alpha=0.6)
# plt.show()


# ==================================================================
# ANÁLISIS ADICIONAL 1: SUBCUENCAS POR ORDEN DE RED FLUVIAL (STRAHLER)
# ==================================================================
from matplotlib.lines import Line2D

print("\n--- INICIANDO ANÁLISIS ADICIONAL ---")

# Restauramos el 'grid' a su estado original
grid = Grid.from_raster(dem_file, nodata=no_data_value)

# --- Preparación con pyflwdir ---
import pyflwdir
with rasterio.open(dem_file) as src:
    dem_data = src.read(1)
    transform = src.transform
    crs = src.crs
flw = pyflwdir.from_dem(data=dem_data, nodata=no_data_value, transform=transform, latlon=False)
upa = flw.upstream_area(unit='cell')


print("Generando Gráfico 7: Subcuencas por Orden de Red Fluvial (Strahler)...")

# --- CÁLCULOS (SIN CAMBIOS) ---
subbas_strahler, idxs_out_strahler = flw.subbasins_streamorder(min_sto=8)
idxs_out_filtrados = [idx for idx in idxs_out_strahler if catch[np.unravel_index(idx, flw.shape)]]
if idxs_out_filtrados:
    x_outlets, y_outlets = flw.xy(idxs_out_filtrados)
else:
    x_outlets, y_outlets = [], []

# --- VISUALIZACIÓN (SIN CAMBIOS) ---
subbas_strahler_masked = np.where(catch, subbas_strahler, np.nan)
subbas_strahler_masked = np.where(subbas_strahler_masked > 0, subbas_strahler_masked, np.nan)
fig, ax = plt.subplots(figsize=(10, 8))
cmap = plt.get_cmap('tab20b')
im = ax.imshow(subbas_strahler_masked, extent=grid.extent, cmap=cmap, zorder=1)
ax.scatter(x_outlets, y_outlets, color='black', s=30, zorder=2)
strahler_orders = flw.stream_order()
unique_basins = np.unique(subbas_strahler_masked[~np.isnan(subbas_strahler_masked)])
legend_elements = []
for basin_id in unique_basins:
    mask = subbas_strahler_masked == basin_id
    max_order_in_basin = int(np.max(strahler_orders[mask]))
    color = im.cmap(im.norm(basin_id))
    legend_elements.append(Line2D([0], [0], marker='o', color='w',
                                  markerfacecolor=color, markersize=10,
                                  label=f'Orden {max_order_in_basin}'))
#ax.legend(handles=legend_elements, title="Orden del Río Principal", frameon=True, loc='upper right')
ax.set_title('Subcuencas por Orden de Red Fluvial Mínimo (Strahler)')
ax.set_xlabel('Coordenada X (UTM)'); ax.set_ylabel('Coordenada Y (UTM)'); plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# --- EXPORTACIÓN A SHAPEFILE DEL GRÁFICO 7 ---
print("Exportando resultados del Gráfico 7 a Shapefile...")

# 1. Exportar los POLÍGONOS de las subcuencas
# Vectorizamos el ráster de subcuencas (solo la parte dentro de nuestra cuenca principal)
shapes = features.shapes(subbas_strahler_masked.astype(np.float32), 
                         mask=~np.isnan(subbas_strahler_masked), 
                         transform=transform)
# Creamos el GeoDataFrame
subbas_geoms = [{'geometry': Polygon(s['coordinates'][0]), 'basin_id': int(v)} for s, v in shapes]
gdf_subbas_strahler = gpd.GeoDataFrame(subbas_geoms, crs=crs)
strahler_basins_path = os.path.join(output_dir, 'subcuencas_strahler.shp')
gdf_subbas_strahler.to_file(strahler_basins_path)
print(f"   -> Subcuencas de Strahler guardadas en: {strahler_basins_path}")

# 2. Exportar los PUNTOS de salida
# Creamos el GeoDataFrame a partir de las coordenadas ya filtradas
gdf_out_strahler = gpd.GeoDataFrame(geometry=gpd.points_from_xy(x_outlets, y_outlets), crs=crs)
strahler_points_path = os.path.join(output_dir, 'puntos_strahler.shp')
gdf_out_strahler.to_file(strahler_points_path)
print(f"   -> Puntos de Strahler guardados en: {strahler_points_path}")

# ==================================================================
# ANÁLISIS ADICIONAL 1: RED FLUVIAL POR ORDEN DE STRAHLER (Gráfico 7)
# ==================================================================
print("\n--- INICIANDO ANÁLISIS ADICIONAL ---")

# Restauramos el 'grid' a su estado original
grid = Grid.from_raster(dem_file, nodata=no_data_value)

# --- Preparación con pyflwdir ---
import pyflwdir
with rasterio.open(dem_file) as src:
    dem_data = src.read(1)
    transform = src.transform
    crs = src.crs
flw = pyflwdir.from_dem(data=dem_data, nodata=no_data_value, transform=transform, latlon=False)
upa = flw.upstream_area(unit='cell')

print("Generando Gráfico 7: Red Fluvial por Orden de Strahler...")

# --- CÁLCULOS (SIN CAMBIOS) ---
stream_mask = upa > 1600
strahler_orders = flw.stream_order(mask=stream_mask, type='strahler')
stream_features = flw.streams(mask=stream_mask, strord=strahler_orders)
gdf_streams_full = gpd.GeoDataFrame.from_features(stream_features, crs=crs)
shapes = features.shapes(catch.astype(np.uint8), mask=catch, transform=transform)
cuenca_geom = [Polygon(s['coordinates'][0]) for s, v in shapes if v == 1][0]
gdf_cuenca = gpd.GeoDataFrame(geometry=[cuenca_geom], crs=crs)
gdf_streams_recortado = gpd.clip(gdf_streams_full, gdf_cuenca)

# --- VISUALIZACIÓN (CON ESTILO MEJORADO) ---
grid_plot = Grid.from_raster(dem_file, nodata=no_data_value)
grid_plot.clip_to(catch)
dem_view = grid_plot.view(conditioned_dem, nodata=np.nan)

fig, ax = plt.subplots(figsize=(10, 8))

# ***** CAMBIO 1: Fondo en escala de grises para un efecto 'hillshade' *****
# En lugar de 'terrain', usamos 'Greys_r' para un relieve sombreado.
ax.imshow(dem_view, extent=grid_plot.extent, cmap='Greys_r', alpha=0.8, zorder=1)

# ***** CAMBIO 2: Rampa de colores azules para los ríos *****
# Cambiamos 'viridis' por 'Blues' para replicar el estilo de la web.
gdf_streams_recortado.plot(ax=ax, column='strord', cmap='Blues', zorder=2,
                           legend=True, categorical=True,
                           legend_kwds={'title': "Orden de Strahler", 'loc': 'upper right'})

ax.set_title('Red Fluvial por Orden de Strahler (Recortada a la Cuenca)')
ax.set_xlabel('Coordenada X (UTM)')
ax.set_ylabel('Coordenada Y (UTM)')
# Quitamos la rejilla para un look más limpio, como en el ejemplo
# plt.grid(True, linestyle='--', alpha=0.6)
ax.set_frame_on(False) # Quitamos el marco
ax.tick_params(axis='both', which='both', length=0) # Quitamos las marcas de los ejes

plt.show()

# Renombramos el siguiente gráfico para que sea el 7-bis
print("\nGenerando Gráfico 7-bis: Subcuencas coloreadas por Orden de Strahler...")

# --- EXPORTACIÓN A SHAPEFILE DEL GRÁFICO 7 ---
print("Exportando la red fluvial de Strahler a Shapefile...")

try:
    # Definimos el nombre del archivo de salida
    strahler_streams_path = os.path.join(output_dir, 'rios_strahler.shp')
    
    # ***** LA SOLUCIÓN DEFINITIVA ESTÁ AQUÍ *****
    # Filtramos para quedarnos solo con geometrías de LÍNEA o MULTILÍNEA,
    # eliminando cualquier geometría degenerada (como Points o GeometryCollections)
    # que se haya podido generar durante el recorte.
    allowed_types = ["LineString", "MultiLineString"]
    gdf_final_export = gdf_streams_recortado[gdf_streams_recortado.geom_type.isin(allowed_types)]

    # Guardamos el GeoDataFrame ya filtrado y limpio
    gdf_final_export.to_file(strahler_streams_path)
    
    print(f"   -> Red fluvial con orden de Strahler guardada en: {strahler_streams_path}")
    print("      (La tabla de atributos contiene la columna 'strord')")

except Exception as e:
    print(f"\n--- ERROR DURANTE LA EXPORTACIÓN DE LOS RÍOS DE STRAHLER ---")
    print(f"Ocurrió un error: {e}")


# ==================================================================
# ANÁLISIS ADICIONAL 2: SUBCUENCAS PFAFSTETTER (CON LEYENDA PERSONALIZADA)
# ==================================================================
from matplotlib.lines import Line2D # Importamos la herramienta para crear la leyenda

print("Generando Gráfico 8: Subcuencas Pfafstetter (Orden 1)...")

# --- CÁLCULOS PARA ORDEN 1 (SIN CAMBIOS) ---
subbas_pfaf_1_full, idxs_out_pfaf1 = flw.subbasins_pfafstetter(depth=1)
idxs_out_pfaf1_filtrados = [idx for idx in idxs_out_pfaf1 if catch[np.unravel_index(idx, flw.shape)]]
if idxs_out_pfaf1_filtrados:
    x_outlets_pfaf1, y_outlets_pfaf1 = flw.xy(idxs_out_pfaf1_filtrados)
else:
    x_outlets_pfaf1, y_outlets_pfaf1 = [], []
pfaf1_masked = np.where(catch, subbas_pfaf_1_full, np.nan)
pfaf1_masked = np.where(pfaf1_masked > 0, pfaf1_masked, np.nan)

# --- VISUALIZACIÓN DE ORDEN 1 (CON LEYENDA PERSONALIZADA) ---
fig, ax = plt.subplots(figsize=(10, 8))
cmap = plt.get_cmap('tab20b') # Obtenemos el mapa de colores para usarlo en la leyenda
im_pfaf1 = ax.imshow(pfaf1_masked, extent=grid.extent, cmap=cmap, zorder=1)
ax.scatter(x_outlets_pfaf1, y_outlets_pfaf1, color='black', s=30, zorder=2)

# Crear la leyenda personalizada
unique_basins = np.unique(pfaf1_masked[~np.isnan(pfaf1_masked)])
norm = plt.Normalize(vmin=1, vmax=9) # Normalizamos de 1 a 9 para obtener los colores correctos
legend_elements = [Line2D([0], [0], marker='o', color='w',
                          markerfacecolor=cmap(norm(basin_id)), markersize=10,
                          label=f'{int(basin_id)}') for basin_id in unique_basins]
ax.legend(handles=legend_elements, title="Pfafstetter\nlevel 1 index [-]", 
          ncol=3, frameon=False, loc='upper right')

ax.set_title('Subcuencas por Codificación Pfafstetter (Orden 1)')
ax.set_xlabel('Coordenada X (UTM)'); ax.set_ylabel('Coordenada Y (UTM)')
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()


print("Generando Gráfico 9: Subcuencas Pfafstetter (Orden 2)...")

# --- CÁLCULOS PARA ORDEN 2 (SIN CAMBIOS) ---
area_threshold = 16000
subbas_pfaf_2_full, idxs_out_pfaf2 = flw.subbasins_pfafstetter(depth=2, upa_min=area_threshold)
idxs_out_pfaf2_filtrados = [idx for idx in idxs_out_pfaf2 if catch[np.unravel_index(idx, flw.shape)]]
if idxs_out_pfaf2_filtrados:
    x_outlets_pfaf2, y_outlets_pfaf2 = flw.xy(idxs_out_pfaf2_filtrados)
else:
    x_outlets_pfaf2, y_outlets_pfaf2 = [], []
mask_level2 = (subbas_pfaf_2_full > 0) & catch
pfaf2_colored_by_pfaf1 = np.where(mask_level2, subbas_pfaf_2_full // 10, np.nan)

# --- VISUALIZACIÓN DE ORDEN 2 (CON LEYENDA PERSONALIZADA) ---
fig, ax = plt.subplots(figsize=(10, 8))
im_pfaf2 = ax.imshow(pfaf2_colored_by_pfaf1, extent=grid.extent, cmap=cmap, zorder=1)
ax.scatter(x_outlets_pfaf2, y_outlets_pfaf2, color='black', s=30, zorder=2)

# Crear la leyenda personalizada (reutilizamos la misma lógica)
unique_basins_l2 = np.unique(pfaf2_colored_by_pfaf1[~np.isnan(pfaf2_colored_by_pfaf1)])
legend_elements_l2 = [Line2D([0], [0], marker='o', color='w',
                             markerfacecolor=cmap(norm(basin_id)), markersize=10,
                             label=f'{int(basin_id)}') for basin_id in unique_basins_l2]
ax.legend(handles=legend_elements_l2, title="Pfafstetter\nlevel 1 index [-]", 
          ncol=3, frameon=False, loc='upper right')

ax.set_title('Subcuencas por Codificación Pfafstetter (Orden 2)')
ax.set_xlabel('Coordenada X (UTM)'); ax.set_ylabel('Coordenada Y (UTM)')
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

# ==================================================================
# ANÁLISIS ADICIONAL 3: SUBCUENCAS POR ÁREA MÍNIMA (CON LEYENDA DE ÁREA)
# ==================================================================
print("Generando Gráfico 10: Subcuencas por Área Mínima de Aporte...")

# Paso 1: Delinear las subcuencas y obtener sus puntos de salida
min_area_km2 = 10.0
subbas_area, idxs_out_area = flw.subbasins_area(min_area_km2)

# Paso 2: Crear un mapa de áreas en lugar de un mapa de IDs
# Inicializamos un nuevo ráster vacío
area_map = np.full(flw.shape, np.nan, dtype=np.float32)
# Calculamos el área de un píxel en km²
cell_area_km2 = (25 * 25) / 1000000

# Iteramos sobre cada punto de salida para obtener el área de su subcuenca
for idx in idxs_out_area:
    # Coordenadas del punto de salida
    row, col = np.unravel_index(idx, flw.shape)
    # ID de la subcuenca en este punto
    basin_id = subbas_area[row, col]
    # Área de aporte total en este punto (en celdas)
    basin_upa = upa[row, col]
    # Convertimos el área a km²
    basin_area = basin_upa * cell_area_km2
    # En el nuevo mapa, rellenamos todos los píxeles de esta subcuenca con su área
    area_map[subbas_area == basin_id] = basin_area

# Paso 3: Visualizar el nuevo mapa de áreas
# Enmascaramos el resultado para mostrar solo los valores dentro de nuestra cuenca principal ('catch')
final_area_map = np.where(catch, area_map, np.nan)

fig, ax = plt.subplots(figsize=(10, 8))
# Dibujamos el mapa de áreas. Ya no hay puntos.
im_area = ax.imshow(final_area_map, extent=grid.extent, cmap='YlGnBu', zorder=1)

# La leyenda ahora es significativa
plt.colorbar(im_area, ax=ax, label='Área de Aporte (km²)')
ax.set_title(f'Subcuencas con Área de Aporte Mínima > {min_area_km2:.1f} km²')
ax.set_xlabel('Coordenada X (UTM)')
ax.set_ylabel('Coordenada Y (UTM)')
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

print("\n--- Todos los análisis y gráficos han finalizado ---")

# ==================================================================
# ANÁLISIS ADICIONAL 4: LLANURAS DE INUNDACIÓN GEOMÓRFICAS (Gráfico 11)
# ==================================================================
print("Generando Gráfico 11: Llanuras de Inundación Geomórficas...")

# --- CÁLCULOS (SIN CAMBIOS, YA SON CORRECTOS) ---
upa_km2 = flw.upstream_area(unit='km2')
# Guardamos el umbral en una variable para usarlo en el título
upa_min_threshold = 1.0
floodplains = flw.floodplains(elevtn=dem_data, uparea=upa_km2, upa_min=upa_min_threshold)

# --- PREPARACIÓN DE LAS CAPAS PARA VISUALIZACIÓN ---
dem_background = np.where(catch, conditioned_dem, np.nan)
floodplains_masked = np.where(catch & (floodplains > 0), 1.0, np.nan)

# --- VISUALIZACIÓN (CON ESTILO CORREGIDO) ---
fig, ax = plt.subplots(figsize=(10, 8))

# Dibujar el fondo de relieve en escala de grises
ax.imshow(dem_background, extent=grid.extent, cmap='Greys_r', zorder=1)

# Superponer las llanuras de inundación en azul
# ***** LA CORRECCIÓN CLAVE ESTÁ AQUÍ *****
# Añadimos vmin=0 y vmax=1 para forzar que el valor 1.0 se pinte con el azul más oscuro.
im = ax.imshow(floodplains_masked, extent=grid.extent, cmap='Blues', alpha=0.7, zorder=2, vmin=0, vmax=1)

# ***** TÍTULO CORREGIDO *****
ax.set_title(f'Llanuras de Inundación Geomórficas (upa_min > {upa_min_threshold:.1f} km²)')

# Limpiamos los ejes para un look más profesional
ax.set_xlabel('')
ax.set_ylabel('')
ax.set_xticks([])
ax.set_yticks([])
ax.set_frame_on(False)

plt.show()

print("\n--- Script finalizado con éxito ---")
